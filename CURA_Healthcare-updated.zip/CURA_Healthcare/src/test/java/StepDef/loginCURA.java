package StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import pages.Appointment;
import pages.Homepage;
import pages.Login;

public class loginCURA {
    WebDriver driver;
    @Given("User Open website CURA Healthcare with browser Edge")
    public void userOpenWebsiteCURAHealthcareWithBrowserEdge() {
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();

        driver.get("https://katalon-demo-cura.herokuapp.com/");
    }

    @When("User input username {string}, password {string} and Click Sign In")
    public void userInputUsernamePasswordAndClickSignIn(String user, String pass) {
        Login login = new Login(driver);
        login.clickMenuLogin();
        login.enterUsername(user);
        login.enterPassword(pass);
        login.clickLogin();
    }

    @Then("User verify Homepage")
    public void userVerifyHomepage() {
        Homepage home = new Homepage(driver);
        home.verifyHomepage();
    }

    @And("User Click Appointment")
    public void userClickAppointment() throws InterruptedException {
        Homepage home = new Homepage(driver);
        home.clickMakeAppointment();
    }

    @And("User Go To Make Appointment")
    public void userGoToMakeAppointment() throws InterruptedException {
        Homepage home = new Homepage(driver);
        home.goToMakeAppointment();
    }

    @And("User fill the Data {string}, {string}, {string}, {string} about Appointment")
    public void userFillTheDataAboutAppointment(String city, String hc, String date, String com) {
        Homepage home = new Homepage(driver);
        home.verifyHomepage();
        home.facility(city);
        home.hospitalReadmission();
        home.healthcareProgram(hc);
        home.date(date);
        home.comment(com);
        home.submitBookAppointment();
    }

    @Then("User verify Appointment")
    public void userVerifyAppointment() {
        Appointment appointment = new Appointment(driver);
        appointment.verifyAppointment();
    }

    @And("User fill the Date {string} about Appointment")
    public void userFillTheDateAboutAppointment(String date) {
        Homepage home = new Homepage(driver);
        home.verifyHomepage();
        home.date(date);
        home.submitBookAppointment();
    }
}
