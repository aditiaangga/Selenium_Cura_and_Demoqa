package slider;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class slider {
    @Test
    public void slider() {
        WebDriverManager.edgedriver().setup();
        EdgeDriver driver = new EdgeDriver();

        driver.get("https://demoqa.com/slider");

        WebElement fixedban = driver.findElement(By.id("fixedban"));
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].parentNode.removeChild(arguments[0])", fixedban);

        Actions act = new Actions(driver);
        WebElement from = driver.findElement(By.xpath("//input[@type='range']"));
        System.out.println(from.getText());
        act.dragAndDropBy(from, 150,0).perform();
        WebElement sv = driver.findElement(By.id("sliderValue"));
        System.out.println(sv.getAttribute("value"));
        Assertions.assertEquals("96",sv.getAttribute("value"));

        act.dragAndDropBy(from, -50,0).perform();
        System.out.println(sv.getAttribute("value"));
        Assertions.assertEquals("35",sv.getAttribute("value"));

        act.dragAndDropBy(from, 120,0).perform();
        System.out.println(sv.getAttribute("value"));
        Assertions.assertEquals("87",sv.getAttribute("value"));

        act.dragAndDropBy(from, -100,0).perform();
        System.out.println(sv.getAttribute("value"));
        Assertions.assertEquals("19",sv.getAttribute("value"));

        act.dragAndDropBy(from, 40,0).perform();
        System.out.println(sv.getAttribute("value"));
        Assertions.assertEquals("62",sv.getAttribute("value"));

        act.dragAndDropBy(from, -30,0).perform();
        System.out.println(sv.getAttribute("value"));
        Assertions.assertEquals("41",sv.getAttribute("value"));
    }
}
